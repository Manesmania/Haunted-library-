Open index.html to preview. Upload this folder to Netlify or GitHub Pages for a free public website. Images are embedded in the HTML so they display even when opened locally on most devices.
